<?php
/**
 * Plugin Name: WPGraphQL for eCommerce (WooGraphQL)
 * Plugin URI: https://github.com/wp-graphql/wp-graphql-woocommerce
 * Description: Adds WooCommerce functionality to WPGraphQL schema.
 * Version: 1.0.2
 * Author: kidunot89
 * Author URI: https://axistaylor.com
 * Text Domain: wp-graphql-woocommerce
 * Domain Path: /languages
 * License: GPL-3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Requires at least: 6.3
 * Requires PHP: 8.1
 * WC requires at least: 9.0.0
 * WC tested up to: 10.4.3
 * WPGraphQL requires at least: 2.0.0
 * WPGraphQL-JWT-Authentication requires at least: 0.7.0+
 * WPGraphQL-Headless-Login requires at least: 0.1.4+
 *
 * @package     WPGraphQL\WooCommerce
 * @author      kidunot89
 * @license     GPL-3
 */

namespace WPGraphQL\WooCommerce;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * If the codeception remote coverage file exists, require it.
 *
 * This file should only exist locally or when CI bootstraps the environment for testing
 */
if ( file_exists( __DIR__ . '/c3.php' ) ) {
	require_once __DIR__ . '/c3.php';
}

/**
 * Setups WPGraphQL for WooCommerce constants
 *
 * @return void
 */
function constants() {
	// Plugin version.
	if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_VERSION' ) ) {
		define( 'WPGRAPHQL_WOOCOMMERCE_VERSION', '1.0.2' );
	}
	// Plugin Folder Path.
	if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_DIR' ) ) {
		define( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
	}
	// Plugin Folder URL.
	if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_URL' ) ) {
		define( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	}
	// Plugin Root File.
	if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_FILE' ) ) {
		define( 'WPGRAPHQL_WOOCOMMERCE_PLUGIN_FILE', __FILE__ );
	}
	// Whether to autoload the files or not.
	if ( ! defined( 'WPGRAPHQL_WOOCOMMERCE_AUTOLOAD' ) ) {
		define( 'WPGRAPHQL_WOOCOMMERCE_AUTOLOAD', true );
	}
}

/**
 * Returns path to plugin root directory.
 *
 * @return string
 */
function get_plugin_directory() {
	return trailingslashit( WPGRAPHQL_WOOCOMMERCE_PLUGIN_DIR );
}

/**
 * Returns path to plugin "includes" directory.
 *
 * @return string
 */
function get_includes_directory() {
	return trailingslashit( WPGRAPHQL_WOOCOMMERCE_PLUGIN_DIR ) . 'includes/';
}

/**
 * Returns path to plugin "vendor" directory.
 *
 * @return string
 */
function get_vendor_directory() {
	return trailingslashit( WPGRAPHQL_WOOCOMMERCE_PLUGIN_DIR ) . 'vendor/';
}

/**
 * Returns url to a plugin file.
 *
 * @param string $filepath  Relative path to plugin file.
 *
 * @return string
 */
function plugin_file_url( $filepath ) {
	return plugins_url( $filepath, __FILE__ );
}

/**
 * Checks if WPGraphQL for WooCommerce required plugins are installed and activated
 *
 * @param array $deps  Unloaded dependencies list.
 *
 * @return array
 */
function dependencies_not_ready( &$deps = [] ) {
	if ( ! class_exists( '\WPGraphQL' ) ) {
		$deps[] = 'WPGraphQL';
	}
	if ( ! class_exists( '\WooCommerce' ) ) {
		$deps[] = 'WooCommerce';
	}

	return $deps;
}

/**
 * Initializes WPGraphQL for WooCommerce
 *
 * @return void
 */
function init() {
	// We define this now and pass it as a reference.
	$not_ready = [];

	if ( empty( dependencies_not_ready( $not_ready ) ) ) {
		require_once get_includes_directory() . 'class-wp-graphql-woocommerce.php';
		WP_GraphQL_WooCommerce::instance();
		return;
	}

	foreach ( $not_ready as $dep ) {
		add_action(
			'admin_notices',
			static function () use ( $dep ) {
				?>
				<div class="error notice">
					<p>
						<?php
							printf(
								/* translators: dependency not ready error message */
								esc_html__( '%1$s must be active for "WPGraphQL for WooCommerce (WooGraphQL)" to work', 'wp-graphql-woocommerce' ),
								esc_html( $dep )
							);
						?>
					</p>
				</div>
				<?php
			}
		);
	}
}

add_action( 'graphql_init', 'WPGraphQL\WooCommerce\init' );

/**
 * Initializes Protected Router
 *
 * @return void
 */
function init_auth_router() {
	if ( empty( dependencies_not_ready() ) ) {
		require_once get_includes_directory() . 'class-wp-graphql-woocommerce.php';
		WP_GraphQL_WooCommerce::load_auth_router();
	}
}

add_action( 'plugins_loaded', 'WPGraphQL\WooCommerce\init_auth_router' );

/**
 * Prevent WooCommerce from loading cart during 'init' for GraphQL requests.
 *
 * WooCommerce calls wc_load_cart() during the 'init' action for frontend requests.
 * This happens before JWT authentication can set the current user, causing the
 * session to be initialized with the wrong user context.
 *
 * By making WooCommerce think GraphQL requests are REST API requests, we prevent
 * the early cart loading. The cart is then loaded later during 'graphql_before_execute'
 * after JWT authentication has had a chance to run.
 *
 * @return void
 */
function prevent_early_wc_cart_loading() {
	if ( ! function_exists( 'is_graphql_http_request' ) || ! is_graphql_http_request() ) {
		return;
	}

	add_filter( 'woocommerce_is_rest_api_request', '__return_true' );
}

add_action( 'plugins_loaded', 'WPGraphQL\WooCommerce\prevent_early_wc_cart_loading', 0 );

// Load constants.
constants();

// Load access functions.
require_once get_plugin_directory() . 'access-functions.php';

// Confirm WC HPOS and Cart & Checkout Blocks compatibility.
// Only declare when installed as a top-level plugin (not nested in another plugin's vendor directory).
add_action(
	'before_woocommerce_init',
	static function () {
		$is_top_level_plugin = dirname( __DIR__ ) === WP_PLUGIN_DIR;
		if ( ! $is_top_level_plugin ) {
			return;
		}

		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

/**
 * Disable deferred transactional emails during tests so WC emails send
 * synchronously and can be captured by MockPHPMailer. This must run before
 * WC_Emails is instantiated, which happens during plugins_loaded — too early
 * for the wpunit bootstrap.php to hook in.
 */
if ( defined( 'GRAPHQL_TESTING' ) && GRAPHQL_TESTING ) {
	add_filter( 'woocommerce_defer_transactional_emails', '__return_false' );
}
