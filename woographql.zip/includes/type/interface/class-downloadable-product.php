<?php
/**
 * Defines the "DownloadableProduct" interface.
 *
 * @package WPGraphQL\WooCommerce\Type\WPInterface
 * @since   0.17.0
 */

namespace WPGraphQL\WooCommerce\Type\WPInterface;

/**
 * Class Downloadable_Product
 */
class Downloadable_Product {
	/**
	 * Registers the "DownloadableProduct" type
	 *
	 * @return void
	 * @throws \Exception
	 */
	public static function register_interface(): void {
		register_graphql_interface_type(
			'DownloadableProduct',
			[
				'description' => static function () {
					return __( 'A downloadable product.', 'wp-graphql-woocommerce' );
				},
				'interfaces'  => [ 'Node' ],
				'fields'      => self::get_fields(),
				'resolveType' => 'wc_graphql_resolve_product_type',
			]
		);
	}

	/**
	 * Defines fields of "DownloadableProduct".
	 *
	 * @return array
	 */
	public static function get_fields() {
		return [
			'id'             => [
				'type'        => [ 'non_null' => 'ID' ],
				'description' => static function () {
					return __( 'Product or variation global ID', 'wp-graphql-woocommerce' );
				},
			],
			'databaseId'     => [
				'type'        => [ 'non_null' => 'Int' ],
				'description' => static function () {
					return __( 'Product or variation ID', 'wp-graphql-woocommerce' );
				},
			],
			'downloadExpiry' => [
				'type'        => 'Int',
				'description' => static function () {
					return __( 'Download expiry', 'wp-graphql-woocommerce' );
				},
			],
			'downloadable'   => [
				'type'        => 'Boolean',
				'description' => static function () {
					return __( 'Is downloadable?', 'wp-graphql-woocommerce' );
				},
			],
			'downloadLimit'  => [
				'type'        => 'Int',
				'description' => static function () {
					return __( 'Download limit', 'wp-graphql-woocommerce' );
				},
			],
			'downloads'      => [
				'type'        => [ 'list_of' => 'ProductDownload' ],
				'description' => static function () {
					return __( 'Product downloads', 'wp-graphql-woocommerce' );
				},
			],
		];
	}
}
